//
//  secondView.swift
//  DalyaTask
//
//  Created by Dalya Bazuhair on 12/02/1446 AH.
//

import SwiftUI

struct secondView: View {
    let images = ["workout 1", "workout 2", "workout 3", "workout 4","workout 5", "workout 6"]
    @State private var selectedDate = Date()
    let columns = [
           GridItem(.flexible()),
           GridItem(.flexible())
       ]
    var body: some View {
        
        VStack{
            
            //for title and date picker
            VStack{
                HStack() {
                    
                    Text("Training")
                        .font(.title)
                        .padding()
                    
                    // Date Picker
                    DatePicker(
                        "",
                        selection: $selectedDate,
                        displayedComponents: .date
                    )
                    .datePickerStyle(CompactDatePickerStyle())
                    .padding()}}
               
                ScrollView {
                    
                    ZStack{
                        
                        RoundedRectangle(cornerSize: CGSize(width: 20, height: 10), style: .continuous)
                            .frame(width:350,height: 200)
                            .foregroundColor(.gray.opacity(0.2))
                        
                        HStack {
                            Image("workout")
                                .resizable()
                                .frame(width: 140, height: 200)
                            VStack(alignment: .leading, spacing: 5) {
                                Text("You are doing great!")
                                    .font(.title2)
                                    .foregroundColor(.blue)
                                Text("Keep it up")
                                Text("Stick to your plans")
                            }
                        }
                        .padding() 
                    }
                            LazyVGrid(columns: columns, spacing: 20) {
                                ForEach(images, id: \.self) { imageName in
                                    
                                    ZStack{
                                        RoundedRectangle(cornerSize: CGSize(width: 20, height: 20), style: .continuous)
                                            .foregroundColor(.gray.opacity(0.4))
                                        
                                        Image(imageName)
                                        .resizable()
                                        .aspectRatio(contentMode: .fill)
                                        
                                        .clipped()
                                        .cornerRadius(10)
                                        .shadow(color: .gray, radius: 5, x: 0, y: 5)
                                        .padding()
                                    }
                            }
                            }
                            .padding()
                        }
                    }
        
    }
}

#Preview {
    secondView()
}

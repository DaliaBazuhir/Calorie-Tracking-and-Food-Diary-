//
//  CardView.swift
//  DalyaTask
//
//  Created by Dalya Bazuhair on 11/02/1446 AH.
//

import SwiftUI


struct CardView: View {
    
    
    var img: String
    var text: String
    var items: String
    var calories : String
    
    //card  with meals details and image
    var body: some View {
         ZStack{
            ZStack{
                
                RoundedRectangle(cornerRadius: 30)
                    .frame(width: 200,height: 200).foregroundColor(.gray.opacity(0.4))
                // image of card
                VStack{
                    Image(img)
                        .resizable()
                        .frame(width: 80, height: 80)
                        .clipShape(Circle())
                        .overlay {
                            Circle()
                                .foregroundColor(.white)
                                .opacity(0.3)
                        }
                        .shadow(radius: 7)
                        .offset(x:0,y:1)
                    
                    // title of meal
                    Text(text)
                        .font(.callout)
                        .foregroundColor(.white)
                    
                    // description of meal 
                    
                    Text(items).font(.caption)
                   
                    
                    HStack{
                        
                        // meal caloris
                        Text(calories).font(.caption)
                        Text("kcal").font(.caption2)
                        
                        
                        
                    }
                }
                .foregroundColor(.white)
                .padding(.top,2)
                
            }
            
        }
    }
}
#Preview {
    CardView(img: "breakfast", text: "Breakfast", items: "Eggs,toast", calories: "130")
}


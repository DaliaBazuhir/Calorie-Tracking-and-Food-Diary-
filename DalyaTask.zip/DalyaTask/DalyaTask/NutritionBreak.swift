//
//  NutritionBreak.swift
//  Task
//
//  Created by Dalya Bazuhair on 10/02/1446 AH.
//

import SwiftUI

struct NutritionBreak: View {
  
    var progressViewWidth: Double = 80
    var progressViewHeigth: Double = 30


    var body: some View {
        
                
            HStack{
                
                ProgressView(value: 88,total: 100, label:{Text("Carbs")}, currentValueLabel: {Text("12g left")})
                    .frame(width:progressViewWidth)
                    .tint(.blue)
                    .padding(/*@START_MENU_TOKEN@*/EdgeInsets()/*@END_MENU_TOKEN@*/)
                
                ProgressView(value: 40,total: 100, label: {Text("Protein")}, currentValueLabel: {Text("30g left")})
                    .frame(width: progressViewWidth)
                    .tint(.pink).padding()
                
                ProgressView(value: 30, total: 100, label: {Text("Fat")}, currentValueLabel: {Text("10g left")})
                    .frame(width: progressViewWidth)
                    .tint(.yellow).padding()
                
            }
        }

    //}
}

#Preview {
    NutritionBreak()
}

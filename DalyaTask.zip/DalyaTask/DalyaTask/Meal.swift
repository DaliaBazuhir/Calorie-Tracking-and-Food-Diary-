//
//  Meal.swift
//  DalyaTask
//
//  Created by Dalya Bazuhair on 11/02/1446 AH.
//

import Foundation
import SwiftUI

struct Meal: Identifiable {
    let id = UUID()
    var mealImage: String
    var mealName: String
    var mealIngredients :String
    var mealKcal: String
}



extension Meal {
  static let samples = [
    Meal(mealImage: "breakfast", mealName: "Breakfast", mealIngredients:"Bread, Peanut, butter",mealKcal: "525"),
    
    Meal(mealImage: "lunch", mealName: "Lunch", mealIngredients:"meat",mealKcal: "602"),
    
    Meal(mealImage: "snack", mealName: "Snack", mealIngredients:"fruit",mealKcal: "525"),
    
  ]
}

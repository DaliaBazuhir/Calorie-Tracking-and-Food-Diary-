//
//  ProgressRing.swift
//  DalyaTask
//


import SwiftUI

struct ProgressRing: View {
    @State private var caloriesConsumed: Double = 1503
    let goal: Double = 1.0
    var circleWidth: Double = 120
    var circleHeight: Double = 150

    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 10) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Eaten")
                        .fontWeight(.semibold)
                    HStack {
                        Circle()
                            .frame(width: 15, height: 15)
                            .foregroundColor(.blue.opacity(0.3))
                        Text("1127").bold()
                        Text("kcal")
                            .font(.callout)
                            .foregroundStyle(.gray)
                    }
                }

                VStack(alignment: .leading, spacing: 4) {
                    Text("Burned")
                        .fontWeight(.semibold)
                    HStack {
                        Circle()
                            .frame(width: 15, height: 15)
                            .foregroundColor(.red.opacity(0.3))
                        Text("102").bold()
                        Text("kcal")
                            .font(.callout)
                            .foregroundStyle(.gray)
                    }
                }
            }
            
            Spacer()
            
            ZStack {
                Circle()
                    .trim(from: 0.0, to: 1.0)
                    .stroke(Color.gray.opacity(0.2), lineWidth: 5)
                    .frame(width: circleWidth, height: circleHeight)
                
                Circle()
                    .trim(from: 0.0, to: 0.34)
                    .stroke(Color.blue.opacity(0.5), style: StrokeStyle(lineWidth: 14, lineCap: .round))
                    .frame(width: circleWidth, height: circleHeight)
                    .rotationEffect(.degrees(-90))
                
                VStack {
                    Text("\(Int(caloriesConsumed))")
                        .font(.title)
                        .foregroundColor(.blue)
                    
                    Text("Kcal left")
                        .font(.callout)
                        .foregroundColor(.gray)
                        .frame(alignment: .bottom)
                }
            }
            .padding(.leading)
        }
        .padding()
    }
}

#Preview {
    ProgressRing()
}

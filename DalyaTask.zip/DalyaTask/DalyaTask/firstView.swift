//
//  ContentView.swift
//  DalyaTask
//
//  Created by Dalya Bazuhair on 11/02/1446 AH.
//

import SwiftUI

struct firstView: View {
    
    let RoundedRectangleWidth :Double = 20
    let RoundedRectangleHeight :Double = 20
    @State private var meals = Meal.samples
    
    @State private var isAddReminderDialogPresented = false

    private func presentAddReminderView() {
      isAddReminderDialogPresented.toggle()}
    @State private var selectedDate = Date()
    
    var body: some View {
        // to make all element vertically
        VStack{
            
            //for title and date picker
            VStack{
                HStack() {
                    
                    Text("My Dairy")
                        .font(.title)
                        .padding()
                    
                    // Date Picker
                    DatePicker(
                        "",
                        selection: $selectedDate,
                        displayedComponents: .date
                    )
                    .datePickerStyle(CompactDatePickerStyle())
                    .padding()}
            
                // Scrollabel part
            ScrollView{
                  // first category
                    ZStack{
                        
                        RoundedRectangle(cornerSize: CGSize(width: 20, height: 10), style: .continuous)
                            .frame(height: 250)
                            .foregroundColor(.gray.opacity(0.2))
                        VStack {
                            ProgressRing()
                            Divider().frame(width: 250, height: 0.5)
                                .background(Color.gray)
                            NutritionBreak()
                        }
                    }
                
                // second category
                ZStack{
                    RoundedRectangle(cornerSize: CGSize(width: 20, height: 10), style: .continuous)
                        .frame(height: 300)
                        .foregroundColor(.gray.opacity(0.2))
                    
                    VStack {
                        //button to add new card
                        Button(action: presentAddReminderView) {
                          HStack {
                            Image(systemName: "plus.circle.fill")
                            Text("New Meal")
                            
                          }
                        }.sheet(isPresented: $isAddReminderDialogPresented) {
                            AddNewCard { newMeal in
                              meals.append(newMeal)
                            }
                        }.padding(.leading, 200)
                         
                        
                        //horizonal scroll part
                        ScrollView(.horizontal,showsIndicators: false){
                            HStack{
                               ForEach(meals){ meal in
                                   CardView(img: meal.mealImage, text: meal.mealName, items: meal.mealIngredients, calories: meal.mealKcal)
                                }.padding()

                            }
                        }
                            
                        }
                    }
                
                
                    // third scroll part which displays information about weight
                ZStack{
                    RoundedRectangle(cornerSize: CGSize(width: 20, height: 10), style: .continuous)
                        .frame(height: 250)
                        .foregroundColor(.gray.opacity(0.2))
                    VStack {
                        VStack{
                            Text("Body measurement").font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/).padding(.trailing,140).foregroundColor(.black.opacity(0.5))
                            
                            Text("Weight").font(.title3).bold().padding(.trailing,280)
                            
                            Text("206.8").font(.title2).foregroundColor(/*@START_MENU_TOKEN@*/.blue/*@END_MENU_TOKEN@*/).padding(.trailing,280)
                        }
                        
                        Divider().frame(width: 250, height: 0.5)
                            .background(Color.gray)
                        HStack{
                            VStack{
                                Text("185 cm").font(.title3).fontWeight(.semibold)
                                Text("Height").fontWeight(.light)
                            }
                            .padding()
                            VStack{
                                Text("27.3 BML").font(.title3).fontWeight(.semibold)
                                Text("Overweight").fontWeight(.light)
                            }
                            .padding()
                            VStack{
                                Text("20%").font(.title3).fontWeight(.semibold)
                                Text("Body fat").fontWeight(.light)
                            }
                            .padding()
                        }
                    }
                }
                    }
                }
            }
        }
}

struct ContentView_P: PreviewProvider {
  static var previews: some View {
    NavigationStack {
      firstView()
      
    }
  }
}

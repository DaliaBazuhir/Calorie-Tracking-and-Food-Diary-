//
//  AddNewCard.swift
//  DalyaTask
//
//  Created by Dalya Bazuhair on 11/02/1446 AH.
//

import SwiftUI

struct AddNewCard: View {
    
    enum FocusableField: Hashable {
        case title
      }


      @FocusState
      private var focusedField: FocusableField?


      @State
      private var newMeal = Meal(mealImage:  "spoon_knif", mealName: "", mealIngredients: "", mealKcal: "")
    
    @Environment(\.dismiss)
    private var dismiss


    var onCommit: (_ newMeal: Meal) -> Void


    private func commit() {
      onCommit(newMeal)
      dismiss()
    }
    
    private func cancel() {
      dismiss()
    }
    
    var body: some View {
        
        NavigationStack {
            // form entries
          Form {
            TextField("Meal Type", text: $newMeal.mealName)
              
              TextField("Meal Ingredients", text: $newMeal.mealIngredients)
              
              TextField("Meal calories", text: $newMeal.mealKcal)
               
          }
           
          .navigationTitle("New Meal")
          .navigationBarTitleDisplayMode(.inline)
          .toolbar {
              // cancel button to cancel adding new meal
            ToolbarItem(placement: .cancellationAction) {
                Button(action: cancel) {
                  Text("Cancel")
                }
              }
              
              // add button to add new meal
            ToolbarItem(placement: .confirmationAction) {
              Button(action: commit) {
                Text("Add")
              }
            }
          }
          .onAppear {
            focusedField = .title
          }
        }
        }
        
    
}


struct AddReminderView_Previews: PreviewProvider {
  static var previews: some View {
      AddNewCard { newMeal in
          print("you added  \(newMeal.mealName) as a new  neal")
    }
  }
}



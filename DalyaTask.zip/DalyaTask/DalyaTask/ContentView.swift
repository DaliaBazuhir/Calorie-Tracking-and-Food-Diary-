//
//  ContentView.swift
//  DalyaTask
//
//  Created by Dalya Bazuhair on 11/02/1446 AH.
//

import SwiftUI
import SwiftUI

struct ContentView: View {
    @State private var selectedIndex = 0

    var body: some View {
        TabView(selection: $selectedIndex) {
            // First Tab
            firstView()
                .tabItem {
                    Image(systemName: "book")
                }
                .tag(0)

            secondView()
                .tabItem {
                    Image(systemName: "shoe")
                }
                .tag(1)

            // Third Tab with Plus Circular Button
            Button(action: {
                // Action for the Plus Button
                print("Plus button tapped")
            }) {
                Circle()
                    .fill(Color.blue)
                    .frame(width: 60, height: 60)
                    .overlay(
                        Image(systemName: "plus")
                            .font(.title)
                            .foregroundColor(.white)
                            
                    )
                    .offset(y: -20) // Adjust the offset if needed
            }
            .tabItem {
                Image(systemName: "plus.circle.fill")
            }
            .tag(2)

            // Fourth Tab
            Text("Food View")
                .tabItem {
                    Image(systemName: "star")
                }
                .tag(3)
            // Fifth Tab
            Text("Profile View")
                .tabItem {
                    Image(systemName: "person")
                }
                .tag(3)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

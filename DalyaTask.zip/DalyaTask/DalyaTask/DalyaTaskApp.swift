//
//  DalyaTaskApp.swift
//  DalyaTask
//
//  Created by Dalya Bazuhair on 11/02/1446 AH.
//

import SwiftUI

@main
struct DalyaTaskApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
